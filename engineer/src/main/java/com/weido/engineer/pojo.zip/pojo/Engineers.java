package com.weido.engineer.pojo;

import com.alibaba.fastjson.annotation.JSONField;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "engineers")
public class Engineers {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int eid;
    private String mobile;
    private String password;
    private String name;
    private String description;
    private boolean sex;
    private Date birthday;
    private String title;
    private String photo;
    @ManyToOne(fetch = FetchType.EAGER)
    @JSONField(serialize = false)
    private ServiceShop serviceShop;
    @ManyToOne(fetch = FetchType.EAGER)
    @JSONField(serialize = false)
    private Roles roles;
    @OneToOne(fetch = FetchType.EAGER)
    @JSONField(serialize = false)
    private EngineerToken engineerToken;
    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isSex() {
        return sex;
    }

    public void setSex(boolean sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public ServiceShop getServiceShop() {
        return serviceShop;
    }

    public void setServiceShop(ServiceShop serviceShop) {
        this.serviceShop = serviceShop;
    }

    public Roles getRoles() {
        return roles;
    }

    public void setRoles(Roles roles) {
        this.roles = roles;
    }

    public EngineerToken getEngineerToken() {
        return engineerToken;
    }

    public void setEngineerToken(EngineerToken engineerToken) {
        this.engineerToken = engineerToken;
    }

    public Engineers(String mobile, String password, String name, String description, boolean sex, Date birthday, String title, String photo, ServiceShop serviceShop, Roles roles) {
        this.mobile = mobile;
        this.password = password;
        this.name = name;
        this.description = description;
        this.sex = sex;
        this.birthday = birthday;
        this.title = title;
        this.photo = photo;
//        this.serviceShop = serviceShop;
//        this.roles = roles;
    }

    public Engineers() {
    }

    @Override
    public String toString() {
        return "Engineers{" +
                "eid=" + eid +
                ", mobile='" + mobile + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", sex=" + sex +
                ", birthday=" + birthday +
                ", title='" + title + '\'' +
                ", photo='" + photo + '\'' +
                ", serviceShop=" + serviceShop +
                ", roles=" + roles +
                ", engineerToken=" + engineerToken +
                '}';
    }
}
