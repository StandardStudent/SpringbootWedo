package com.weido.engineer.pojo;

import com.alibaba.fastjson.annotation.JSONField;

import javax.persistence.*;

@Entity
@Table(name = "comm_orgers")
public class CommOrders {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int oid;
    @ManyToOne(fetch = FetchType.EAGER)
    @JSONField(serialize = false)
    private OrderType orderType;
    private String description;
    @ManyToOne(fetch = FetchType.EAGER)
    @JSONField(serialize = false)
    private User user;
    @ManyToOne(fetch = FetchType.EAGER)
    @JSONField(serialize = false)
    private UserHome userHome;
    private String appraise_byuser;
    private String appraise_description;
    private boolean finished;
    private String appraise_anwser;
    @ManyToOne(fetch = FetchType.EAGER)
    @JSONField(serialize = false)
    private OrderStep orderStep;

    public int getOid() {
        return oid;
    }

    public void setOid(int oid) {
        this.oid = oid;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public void setOrderType(OrderType orderType) {
        this.orderType = orderType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public UserHome getUserHome() {
        return userHome;
    }

    public void setUserHome(UserHome userHome) {
        this.userHome = userHome;
    }

    public String getAppraise_byuser() {
        return appraise_byuser;
    }

    public void setAppraise_byuser(String appraise_byuser) {
        this.appraise_byuser = appraise_byuser;
    }

    public String getAppraise_description() {
        return appraise_description;
    }

    public void setAppraise_description(String appraise_description) {
        this.appraise_description = appraise_description;
    }

    public boolean isFinished() {
        return finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public String getAppraise_anwser() {
        return appraise_anwser;
    }

    public void setAppraise_anwser(String appraise_anwser) {
        this.appraise_anwser = appraise_anwser;
    }

    public OrderStep getOrderStep() {
        return orderStep;
    }

    public void setOrderStep(OrderStep orderStep) {
        this.orderStep = orderStep;
    }

    public CommOrders() {
    }

    public CommOrders(OrderType orderType, String description, User user, UserHome userHome, String appraise_byuser, String appraise_description, boolean finished, String appraise_anwser) {
        this.orderType = orderType;
        this.description = description;
        this.user = user;
        this.userHome = userHome;
        this.appraise_byuser = appraise_byuser;
        this.appraise_description = appraise_description;
        this.finished = finished;
        this.appraise_anwser = appraise_anwser;
    }

    @Override
    public String toString() {
        return "CommOrders{" +
                "oid=" + oid +
                ", orderType=" + orderType +
                ", description='" + description + '\'' +
                ", user=" + user +
                ", userHome=" + userHome +
                ", appraise_byuser='" + appraise_byuser + '\'' +
                ", appraise_description='" + appraise_description + '\'' +
                ", finished=" + finished +
                ", appraise_anwser='" + appraise_anwser + '\'' +
                '}';
    }
}
